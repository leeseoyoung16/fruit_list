#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef int element;
typedef struct {
	char name[100];
}element;
typedef struct ListNode {
	element data;
	struct ListNode* link;
}ListNode;

void error(char* message) {
	fprintf(stderr, "%s", message);
	return;
}
ListNode* search(ListNode* head, element x) {
	ListNode* p = head;

	while (p != NULL) {
		if (p->data == x) return 1;
		p = p->link;
	}
	return NULL;
}


ListNode* insert_first(ListNode* head, element value) {
	
	if (search(head, value) == 1) {
		printf("%s hes been added.\n", value);
	}
	else {
		ListNode* p = (ListNode*)malloc(sizeof(ListNode));
		p->data = value;
		p->link = head;
		head = p;
		return head;
	}
	
}

ListNode* delete(ListNode* head, element value) {
	ListNode* prev = NULL;
	ListNode* curr = head;

	while (curr != NULL) {
		if (search(head, value) == NULL) { 
			if (prev == NULL) {
				head = curr->link;
				free(curr);
			}
			else {
				prev->link = curr->link;
				free(curr);
			}
			printf("%s has been deleted.\n", value.name);
			return head;
		}
		prev = curr;
		curr = curr->link;
	}

	printf("%s is not in the list.\n", value.name);
	return head;
}


void print_list(ListNode* head) {
	printf("Fruit list: \n");
	for (ListNode* p = head; p != NULL; p = p->link)
		printf("%d->", p->data);
	printf("\n");
}



int main(void) {
    ListNode* head = NULL;
    element data;
    char fruit[100];

    strcpy(data.name, "Mango");
    head = insert_first(head, data);
    strcpy(data.name, "Orange");
    head = insert_first(head, data);
    strcpy(data.name, "Apple");
    head = insert_first(head, data);
    strcpy(data.name, "Grape");
    head = insert_first(head, data);
    strcpy(data.name, "Cherry");
    head = insert_first(head, data);
    strcpy(data.name, "Plum");
    head = insert_first(head, data);
    strcpy(data.name, "Guava");
    head = insert_first(head, data);
    strcpy(data.name, "Raspberry");
    head = insert_first(head, data);
    strcpy(data.name, "Banana");
    head = insert_first(head, data);
    strcpy(data.name, "Peach");
    head = insert_first(head, data);

    int answer;

    while (1) {

        printf("(1) Insert new fruit\n");
        printf("(2) Delete the fruit\n");
        printf("(3) Print the deleted list\n");
        printf("(4) Exit\n");
        printf("Enter the menu: ");
        scanf("%d", &answer);

        if (answer > 4 || answer < 1) {
            error("Invalid Menu. Please select again..\n");
        }
        else if (answer == 4) {
            printf("Exit the program.\n\n");
            exit(1);
        }
        else if (answer == 1) {
            printf("Fruit name to add:  ");
            scanf("%s", fruit);
            strcpy(data.name, fruit);
            head = insert_first(head, data);
        }
        else if (answer == 2) {
            printf("Fruit name to delete: ");
            scanf("%s", fruit);
            strcpy(data.name, fruit);
            head = delete(head, data);
        }
        else if (answer == 3) {
            print_list(head);
        }
        printf("\n");
    }

    return 0;
}